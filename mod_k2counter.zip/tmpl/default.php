﻿<?php
/**
* @Author  Mostafa Shahiri
*@license	GNU/GPL http://www.gnu.org/copyleft/gpl.html
**/
 defined('_JEXEC') or die();
 ?>
<div id="k2counter">
<table>
<?php if($show_today){?>
<tr>
<td><?php echo JText::_('MOD_K2COUNTER_TODAY_SHOW');?></td>
<td><?php echo $today; ?></td>
</tr>
<?php }?>
<?php if($show_yesterday){?>
<tr>
<td><?php echo JText::_('MOD_K2COUNTER_YESTERDAY_SHOW');?></td>
<td><?php echo $yesterday; ?></td>
</tr>
<?php }?>
<?php if($show_week){?>
<tr>
<td><?php echo JText::_('MOD_K2COUNTER_WEEK_SHOW');?></td>
<td><?php echo $week; ?></td>
</tr>
<?php }?>
<?php if($show_month){?>
<tr>
<td><?php echo JText::_('MOD_K2COUNTER_MONTH_SHOW');?></td>
<td><?php echo $month; ?></td>
</tr>
<?php }?>
<?php if($show_total){?>
<tr>
<td><?php echo JText::_('MOD_K2COUNTER_TOTAL_SHOW');?></td>
<td><?php echo $total; ?></td>
</tr>
<?php }?>
</table>

</div>
