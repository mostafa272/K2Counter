﻿<?php
/**
* @Author  Mostafa Shahiri
*@license	GNU/GPL http://www.gnu.org/copyleft/gpl.html
**/
defined('_JEXEC') or die();
if(!defined('DS'))
{  define('DS',DIRECTORY_SEPARATOR);
}
// Include the helper class
require_once dirname(__FILE__) . DS . 'helper.php';
jimport( 'joomla.application.module.helper' );
$show_today=$params->get('show_today');
$show_yesterday=$params->get('show_yesterday');
$show_week=$params->get('show_week');
$show_month=$params->get('show_month');
$show_total=$params->get('show_total');
$today=&modK2counterHelper::getToday($params);
$yesterday=&modK2counterHelper::getYesterday($params);
$week=&modK2counterHelper::getWeekly($params);
$month=&modK2counterHelper::getMonthly($params);
$total=&modK2counterHelper::getTotal($params);

// Display the template
require(JModuleHelper::getLayoutPath('mod_k2counter'));

?>